"""Check the exported media and caption timeline; exits nonzero on mismatch."""
import json,subprocess,re
from pathlib import Path
p=Path('out/atalhocred-v3-sincronizado.mp4')
r=subprocess.run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)],check=True,capture_output=True,text=True)
d=json.loads(r.stdout);v=next(s for s in d['streams'] if s['codec_type']=='video');a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'])==(1080,1920),v
assert v['codec_name']=='h264',v
assert v['pix_fmt']=='yuv420p',v
assert v['r_frame_rate']=='30/1',v
assert int(v['nb_frames'])==1080,v
assert abs(float(d['format']['duration'])-36)<.05,d
assert a['codec_name']=='aac',a
assert a['sample_rate']=='48000',a
srt=Path('captions/atalhocred.srt').read_text();assert len(re.findall(r' --> ',srt))==12
assert '00:00:32,910' in srt
print(json.dumps({'duration':d['format']['duration'],'dimensions':[v['width'],v['height']],'frames':v['nb_frames'],'fps':v['r_frame_rate'],'video':v['codec_name'],'audio':a['codec_name'],'audio_channels':a['channels'],'caption_cues':12,'voiceover':True},indent=2))
