"""Check subtitle sentence anchors and export audio alignment at five points.
Requires numpy. Verifies actual decoded AAC against the sample-stable mix.
"""
import json,re,subprocess,wave
from pathlib import Path
import numpy as np
p=Path('out/atalhocred-v3-sincronizado.mp4')
# Anchor measurements from silence detection on locucao-v3.wav (-35 dB, min .18 s).
anchors=np.array([.303563,2.087375,4.915208,7.095479,9.835562,15.252958,17.342521,20.737583,23.517625,27.684271,30.523812,31.670292])
rows=re.findall(r"\[([\d.]+),([\d.]+),'([^']+)'\]",Path('src/timeline.ts').read_text())
starts=np.array([float(a) for a,_,_ in rows]);assert len(starts)==len(anchors)
errors=(starts-anchors)*1000
assert np.max(np.abs(errors))<60,errors
with wave.open('public/audio/mix-v3.wav') as w:
 assert w.getframerate()==48000 and w.getnframes()==36*48000
 ref=np.frombuffer(w.readframes(w.getnframes()),'<i2').reshape(-1,2).mean(1).astype(np.float32)
r=subprocess.run(['ffmpeg','-v','error','-i',str(p),'-ar','48000','-ac','1','-f','s16le','-'],check=True,capture_output=True)
y=np.frombuffer(r.stdout,'<i2').astype(np.float32)
# Downsample to 1.5 kHz to bound correlation cost; deterministic 0.67 ms resolution.
sr=1500;ref=ref[::32];y=y[::32];padding=225
checks=[]
for t in [1,8,16,24,31]:
 a=t*sr;b=a+sr
 template=ref[a:b]; search=y[a-padding:b+padding]
 score=np.correlate(search,template,mode='valid')
 lag=int(np.argmax(score))-padding;ms=lag/sr*1000
 assert abs(ms)<35,(t,ms)
 checks.append({'position_seconds':t,'export_offset_ms':round(ms,3)})
report={'caption_anchor_max_error_ms':round(float(np.max(np.abs(errors))),3),'caption_cues':len(rows),'audio_export_offsets':checks,'voice_duration_samples':1728000,'video_seconds':36}
Path('out/sync-v3.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
