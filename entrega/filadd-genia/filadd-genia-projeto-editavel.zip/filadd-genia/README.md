# Gênia Filadd — teste de movimento 2D

Estudo mudo de 15 s, 1080 × 1920, 30 fps, MP4 H.264/yuv420p. Não é uma campanha final e não é demonstração de fala ou sincronização labial. A imagem original foi baixada do endereço indicado pelo usuário, sem redesenhar a personagem; a composição anima recortes raster em 2D. Não usa objetos, renderização ou câmera 3D.

## O que está implementado

Entrada com mola amortecida, balanço do corpo, pequenos movimentos independentes de cabeça e piscadas com sobreposições 2D de pálpebra. Os olhos abertos, o cabelo, roupa, livro e demais detalhes vêm da imagem original. Os três blocos do roteiro têm letterings animados, corações com borda, recortes de papel, setas e rabiscos. O movimento é determinístico por frame, inclusive as piscadas. A boca mantém o sorriso original: não se move sem áudio.

As mãos seguram o livro na arte fornecida; não foi criado um aceno independente. O rig de recortes é experimental e pode mostrar pequenos encaixes no contorno da cabeça. Para maior naturalidade, obter cabeça, corpo, braço e mão em camadas separadas.

## Tipografia: diferença explícita em relação ao briefing

Tusker Grotesk, Cooper Hewitt e CC Providence Sans não estavam disponíveis. Após o usuário autorizar seguir com as escolhas técnicas, foram usadas **Antonio e Poppins**, que o próprio site indicado referencia em seu HTML. Os arquivos são locais, obtidos do repositório Google Fonts, com licenças OFL incluídas. Isso permite renderizar o teste, mas não representa conformidade integral com a tipografia do briefing. Anotações usam Poppins inclinada, sem alegar que é uma fonte manuscrita oficial. Substituir pelas famílias solicitadas quando os arquivos licenciados estiverem disponíveis.

Paleta: #061b6e, #2424ff, #edf0f5, #ffcb13 e #b597ed. Corações vetoriais evitam diferenças de emojis entre plataformas.

## Instalação e edição

Node 24/npm 11, Remotion 4.0.538, React 19.2 e TypeScript 5.9.3. Chromium em `/usr/bin/chromium`, FFmpeg/ffprobe, Python com Pillow. Usar o checkout existente, sem criar worktrees. Este projeto fica fora do repositório AnaLuizaTeste para preservar as entregas originais.

No diretório deste README:

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run check
npm run preflight
npm run studio -- --no-open
```

Para exportar e conferir parâmetros técnicos:

```sh
npm run render
npm run verify
```

Saída: `out/genia-filadd.mp4`. O pós-processamento automático em `scripts/finalize.py` converte a faixa completa do render para BT.709 limitado/yuv420p, mantendo H.264 e fast-start para reprodução. O intermediário fica em `out/genia-filadd-render.mp4`. O código, a temporização e o rig estão em `src/index.tsx`. O arquivo original WebP e sua conversão PNG sem perda visual estão em `public/`.

## Voz e legendas

Uma tentativa real de síntese com Edge TTS 7.3.1 / pt-BR-FranciscaNeural foi bloqueada pelo proxy: acesso a speech.platform.bing.com retornou 403. Não foi gerada voz utilizável. Não foi usada locução robótica alternativa. O vídeo traz “TESTE 2D · SEM LOCUÇÃO”. Os textos acompanham os blocos do roteiro, não palavras de um áudio inexistente.

Para continuar com locução externa:

1. Gravar as três frases em WAV limpo, preferencialmente 48 kHz, com pausas nos blocos 0–4 s, 4–10 s e 10–15 s.
2. Salvar a faixa completa de 15 s em `public/audio/locucao.wav`.
3. Medir as entradas reais, atualizar `lines` e dividir legendas por frase/palavra conforme o áudio. Não acelerar a voz artificialmente para forçar encaixe.
4. Ativar `voice: true` em `defaultProps`. Isso adiciona áudio e remove a identificação de modo mudo; não cria movimentos de boca.
5. Obter bocas oficiais em camadas ou autorização para desenhar visemas. Implementar a sequência a partir dos fonemas reais, incluindo pausas, e revisar quadro a quadro. Não chamar um movimento aleatório ou envelope de volume de sincronização fonética.
6. Conferir reprodução completa com áudio, nível, ausência de clipping e sincronização antes de entregar uma versão com fala.

## Procedência

Personagem: https://acervo-enem.filadd.com.br/__l5e/assets-v1/229a6dcb-8355-4885-a831-e3f3ebaf5edd/genia-hero.webp

Fontes: https://github.com/google/fonts/tree/main/ofl/antonio e https://github.com/google/fonts/tree/main/ofl/poppins . A imagem mantém os direitos de seus titulares; não há licença nova concedida por este projeto.
