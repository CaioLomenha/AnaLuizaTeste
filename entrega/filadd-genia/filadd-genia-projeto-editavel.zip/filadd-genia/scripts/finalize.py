from pathlib import Path
import subprocess
root=Path(__file__).resolve().parents[1]
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(root/'out/genia-filadd-render.mp4'),'-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-crf','18','-preset','fast','-threads','2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-movflags','+faststart','-an',str(root/'out/genia-filadd.mp4')],check=True)
