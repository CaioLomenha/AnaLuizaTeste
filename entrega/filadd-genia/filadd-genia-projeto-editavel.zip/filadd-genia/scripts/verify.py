import json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'out/genia-filadd.mp4'
r=subprocess.run(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)],capture_output=True,text=True,check=True)
d=json.loads(r.stdout); v=next(x for x in d['streams'] if x['codec_type']=='video')
assert (v['width'],v['height'])==(1080,1920)
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
assert v['r_frame_rate']=='30/1' and int(v['nb_frames'])==450
assert abs(float(d['format']['duration'])-15)<.06
print('MP4: 1080×1920, H.264/yuv420p, 30 fps, 450 frames, 15 s.')
print('Inspeção audiovisual, identidade da personagem e lip sync exigem revisão separada.')
