from pathlib import Path
import sys
from PIL import Image
root=Path(__file__).resolve().parents[1]
required=['public/genia.png','public/fonts/Antonio.ttf','public/fonts/Poppins.ttf']
missing=[p for p in required if not (root/p).is_file()]
if missing:
 print('Render bloqueado: faltam recursos do projeto, sem substituição automática.\n'+'\n'.join(missing))
 sys.exit(1)
with Image.open(root/'public/genia.png') as image:
 if image.size != (1024,1024):
  sys.exit('Revisar coordenadas do rig: a referência prevista é 1024 × 1024; não redimensionar a personagem silenciosamente.')
 if image.mode not in ('RGBA','LA') or image.getchannel('A').getextrema()[0] == 255:
  sys.exit('A imagem precisa de fundo transparente. Recortar o fundo com autorização e revisar as bordas antes de renderizar.')
print('Arquivos presentes. Revisar visualmente o recorte da cabeça e o encaixe no pescoço antes do filme final.')
print('Modo padrão: estudo de movimento sem voz. Não há sincronização labial implementada.')
