import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, Composition, Img, Sequence, cancelRender, continueRender, delayRender, interpolate, registerRoot, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import './style.css';

const lines = [
  {start: 0, end: 4, text: 'Ei! Quem disse que estudar precisa ser sozinho?', title: 'ESTUDAR\nSOZINHO?', note: 'juntos fica melhor'},
  {start: 4, end: 10, text: 'Com a Filadd, você tem apoio pra seguir em frente!', title: 'VOCÊ NÃO TÁ\nSOZINHO!', note: 'um passo de cada vez'},
  {start: 10, end: 15, text: 'Bora estudar juntos?', title: 'BORA?', note: 'vem com a Filadd'},
];

// Flat raster cutouts only. Coordinates are provisional for the 1024² reference.
// This is NOT a viseme rig. Mouth stays unchanged; eyelids are simple 2D overlays.
const Actor: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const enter = spring({frame:f, fps, config:{damping:18, stiffness:105}});
  const nod = Math.sin(f / fps * 2.1) * .7 + (f>120 && f<300 ? Math.sin((f-120)/180*Math.PI)*1.3 : 0);
  const lift = Math.sin(f / fps * 2.1) * 6;
  const blink = Math.max(...[83,207,382].map(center=>Math.max(0,1-Math.abs(f-center)/4)));
  const sway = Math.sin(f/fps*1.3)*0.7;
  return <div style={{position:'absolute', left:28, top:565, width:1024, height:1024, transform:`translateY(${(1-enter)*900+lift}px) rotate(${(1-enter)*-7+sway}deg)`, transformOrigin:'50% 92%'}}>
    <Img src={staticFile('genia.png')} style={{position:'absolute', width:1024, clipPath:'polygon(0px 680px,400px 680px,400px 630px,420px 633px,440px 642px,460px 648px,480px 653px,500px 656px,520px 657px,540px 656px,560px 652px,580px 647px,600px 637px,620px 630px,620px 680px,1024px 680px,1024px 1024px,0px 1024px)'}} />
    <Img src={staticFile('genia.png')} style={{position:'absolute',width:1024,clipPath:'polygon(420px 620px,620px 620px,620px 730px,420px 730px)'}} />
    <div style={{position:'absolute',width:1024,height:1024,transform:`rotate(${nod}deg)`,transformOrigin:'50% 65.24%'}}>
      <Img src={staticFile('genia.png')} style={{width:1024,clipPath:'polygon(0px 0px,1024px 0px,1024px 680px,620px 680px,620px 630px,600px 637px,580px 647px,560px 652px,540px 656px,520px 657px,500px 656px,480px 653px,460px 648px,440px 642px,420px 633px,400px 630px,400px 680px,0px 680px)'}} />
      <svg width="1024" height="1024" style={{position:'absolute',left:0,top:0}}>
        <defs>
          <clipPath id="eyes"><ellipse cx="408" cy="438" rx="53" ry="53"/><ellipse cx="603" cy="438" rx="53" ry="53"/></clipPath>
          <linearGradient id="skin" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#edaa76"/><stop offset="100%" stopColor="#f4bc87"/></linearGradient>
        </defs>
        <g clipPath="url(#eyes)">
          <rect x="350" y="385" width="115" height={54*blink} fill="url(#skin)" /><rect x="350" y={491-53*blink} width="115" height={53*blink} fill="url(#skin)" />
          <rect x="548" y="385" width="115" height={54*blink} fill="url(#skin)" /><rect x="548" y={491-53*blink} width="115" height={53*blink} fill="url(#skin)" /><g opacity={Math.pow(blink,8)} stroke="#ae643e" strokeWidth="3" fill="none"><path d="M365 437 Q407 449 451 437"/><path d="M560 437 Q603 449 646 437"/></g>
        </g>
      </svg>
    </div>
  </div>;
};

const Sticker: React.FC<{scene:number}> = ({scene}) => {
  const f=useCurrentFrame(); const {fps}=useVideoConfig();
  const p=spring({frame:f,fps,config:{damping:17,stiffness:130}});
  return <AbsoluteFill style={{pointerEvents:'none'}}>
    <svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute'}}>
      <path d="M44 92 L980 62 L1028 369 L78 402 L64 331 L35 301 Z" fill={scene===1?'#ffcb13':'#edf0f5'} transform={`translate(0 ${(1-p)*-440})`} />
      <g transform={`translate(910 880) rotate(${Math.sin(f/18)*6}) scale(${p})`}>
        <path d="M0 15 C-50 -35 -88 20 0 82 C88 20 50 -35 0 15" fill="#2424ff" stroke="#edf0f5" strokeWidth="12" />
      </g>
      <path d="M100 638 Q36 664 90 734 M84 706 L90 734 L61 728" stroke="#ffcb13" strokeWidth="8" fill="none" strokeLinecap="round" />
      <path d="M930 540 l22 -22 m-4 52 l32 4 m-60 -55 l-2 -28" stroke="#b597ed" strokeWidth="8" strokeLinecap="round" />
    </svg>
    <div style={{position:'absolute',left:90,top:100,width:900,color:'#061b6e',fontFamily:'Antonio',fontWeight:700,fontSize:scene===2?166:100,lineHeight:1.08,whiteSpace:'pre-line',transform:`translateY(${(1-p)*-440}px) rotate(-2deg)`}}>{lines[scene].title}</div>
    <div style={{position:'absolute',left:85,top:435,color:'#edf0f5',fontFamily:'Poppins',fontStyle:'italic',fontSize:32,transform:'rotate(-4deg)',opacity:interpolate(f,[5,18],[0,1],{extrapolateLeft:'clamp',extrapolateRight:'clamp'})}}>{lines[scene].note}</div>
  </AbsoluteFill>;
};

const Film: React.FC<{voice:boolean}> = ({voice}) => {
  const f=useCurrentFrame();
  const [handle]=useState(()=>delayRender('Carregando fontes oficiais'));
  useEffect(()=>{
    Promise.all([['Antonio','Antonio.ttf'],['Poppins','Poppins.ttf']].map(async([family,file])=>{
      const face=new FontFace(family,`url(${staticFile('fonts/'+file)})`);
      await face.load(); (document.fonts as FontFaceSet & {add(face: FontFace): FontFaceSet}).add(face);
    })).then(()=>continueRender(handle)).catch(cancelRender);
  },[handle]);
  const scene=f<120?0:f<300?1:2;
  return <AbsoluteFill style={{background:'#061b6e'}}>
    <svg width="1080" height="1920" style={{position:'absolute'}}><path d="M0 740 L100 720 L1080 820 L1080 1620 L940 1585 L0 1680Z" fill="#b597ed"/><path d="M0 1440 L1080 1580 L1080 1920 L0 1920Z" fill="#2424ff"/></svg>
    <Actor />
    {lines.map((line,i)=><Sequence key={i} from={line.start*30} durationInFrames={(line.end-line.start)*30}><Sticker scene={i}/></Sequence>)}
    {voice&&<Audio src={staticFile('audio/locucao.wav')} volume={0.9}/>}
    <div style={{position:'absolute',top:1645,left:84,width:912,padding:'26px 34px',boxSizing:'border-box',background:'#edf0f5',color:'#061b6e',fontFamily:'Poppins',fontSize:42,lineHeight:1.23,textAlign:'center',transform:`translateY(${Math.sin(f/30)*2}px)`}}>{lines[scene].text}</div>
    {!voice&&<div style={{position:'absolute',bottom:55,width:'100%',textAlign:'center',fontFamily:'Poppins',fontSize:25,color:'#edf0f5'}}>TESTE 2D · SEM LOCUÇÃO</div>}
  </AbsoluteFill>;
};
const Root: React.FC=()=> <Composition id="GeniaFiladd" component={Film} durationInFrames={450} fps={30} width={1080} height={1920} defaultProps={{voice:false}}/>;
registerRoot(Root);
