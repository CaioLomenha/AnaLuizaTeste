# Filadd — Story 1

Vídeo Remotion independente: 1080 × 1920, 30 fps, 780 frames, 26 segundos, MP4 H.264/yuv420p. Sem áudio, pois não foi solicitada trilha ou locução.

Fontes substitutas autorizadas: Anton (títulos), DejaVu Sans (chat/apoio), Caveat (manuscrito). Arquivos e licenças em public/fonts. Logo branca oficial fornecida pelo usuário: public/logo-filadd.png. O card final segue o briefing; a imagem do story 2 não foi fornecida.

## Editar e renderizar

Usar o diretório existente, sem criar worktrees.

```sh
cd /workspace/filadd-story
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
npm run render
```

Requisitos: Node 24, npm 11, Chromium em /usr/bin/chromium. Saída: out/filadd-story-1.mp4. Código e roteiro: src/index.tsx. Render com concorrência 2.

O PNG out/card-final.png corresponde ao encerramento e pode servir como base visual para o story 2; o sticker de link deve ser adicionado no Instagram.

Versão de leitura: velocidade reduzida à metade. Chat de 0 a 18 s; card final de 18 a 26 s.
