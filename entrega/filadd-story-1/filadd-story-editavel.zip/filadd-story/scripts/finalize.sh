#!/usr/bin/env bash
set -euo pipefail
ffmpeg -v error -y -i out/filadd-story-1.mp4 -vf 'scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p' -c:v libx264 -preset fast -crf 18 -threads 2 -color_range tv -colorspace bt709 -color_primaries bt709 -color_trc bt709 -movflags +faststart out/filadd-story-1-final.mp4
mv out/filadd-story-1-final.mp4 out/filadd-story-1.mp4
