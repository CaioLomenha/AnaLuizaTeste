import json,subprocess
from pathlib import Path
p=Path('out/filadd-story-1.mp4')
d=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
v=next(s for s in d['streams'] if s['codec_type']=='video')
assert (v['width'],v['height'])==(1080,1920)
assert v['r_frame_rate']=='30/1' and int(v['nb_frames'])==780
assert float(v['duration'])==26
assert abs(float(d['format']['duration'])-26)<.05
assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p'
a=next(s for s in d['streams'] if s['codec_type']=='audio')
assert a['codec_name']=='aac' and int(a['channels'])==2
subprocess.run(['ffmpeg','-v','error','-i',str(p),'-f','null','-'],check=True)
r={'resolution':'1080x1920','fps':30,'frames':780,'duration':26,'codec':'H.264','pixel_format':'yuv420p','decode':'passed','audio':'AAC stereo instrumental','logo':'official user-supplied white PNG'}
Path('out/validation.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
