from pathlib import Path
import zipfile
with zipfile.ZipFile('out/filadd-story-editavel.zip','w',zipfile.ZIP_DEFLATED) as z:
 for folder in ['src','public','scripts']:
  for p in Path(folder).rglob('*'):
   if p.is_file(): z.write(p,'filadd-story/'+str(p))
 for name in ['package.json','package-lock.json','tsconfig.json','README.md','out/card-final.png','out/filadd-story-1.mp4','out/validation.json']:
  z.write(name,'filadd-story/'+name)
print('Projeto empacotado com logo oficial e vídeo de 26 s.')
