"""Original light instrumental bed, synthesized locally; no external samples."""
import numpy as np,wave
sr=48000;duration=26;n=sr*duration
mix=np.zeros((n,2),dtype=np.float64)
rng=np.random.default_rng(14);beat=60/108
# Warm keys: Fmaj7, Cmaj7, Am7, G6. Restrained pulse; no notification sounds.
chords=[[53,57,60,64],[48,52,55,59],[45,48,52,55],[43,47,50,52]]
def add(sig,start,pan=0):
 k=int(start*sr)
 if k>=n:return
 sig=sig[:n-k];mix[k:k+len(sig),0]+=sig*np.sqrt((1-pan)/2);mix[k:k+len(sig),1]+=sig*np.sqrt((1+pan)/2)
def tone(midi,dur,amp=.1):
 t=np.arange(int(dur*sr))/sr;freq=440*2**((midi-69)/12)
 env=(1-np.exp(-t*35))*np.exp(-t*2.0)*np.minimum(1,np.maximum(0,dur-t)/.25)
 return amp*env*(np.sin(2*np.pi*freq*t)+.22*np.sin(2*np.pi*2*freq*t)+.07*np.sin(2*np.pi*3*freq*t))
for bar in range(12):
 start=bar*4*beat;ch=chords[bar%4]
 for j,note in enumerate(ch):add(tone(note+12,2.1,.075),start+j*.018,(j-1.5)*.28)
 for b in [0,2]:add(tone(ch[0]-12,.8,.17),start+b*beat)
 for b in range(4):
  t=np.arange(int(.20*sr))/sr
  kick=.12*np.sin(2*np.pi*(49*t+7*(1-np.exp(-t*25))))*np.exp(-t*29)
  if b%2==0:add(kick,start+b*beat)
  noise=rng.normal(0,1,int(.075*sr));noise=np.concatenate([[0],np.diff(noise)]);tt=np.arange(len(noise))/sr
  add(noise*np.exp(-tt*95)*.009,start+(b+.5)*beat,.35 if b%2 else -.35)
fade=np.minimum(1,np.arange(n)/sr/1.0)*np.minimum(1,(n-1-np.arange(n))/sr/1.6)
mix*=fade[:,None]
mix*=.65/max(abs(mix).max(),1e-9)
with wave.open('public/audio/trilha-original.wav','wb') as w:
 w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((mix*32767).astype('<i2').tobytes())
print('Original instrumental: 26s, stereo, 48kHz, 108 BPM.')
