# AtalhoCred — filme vertical

Primeira versão de 42 segundos, 1080 × 1920, 30 fps. Projeto React/Remotion com SVGs originais, Figtree variável e trilha instrumental sintetizada original. Não utiliza imagens de banco ou amostras musicais externas.

## Estado da entrega

A versão `out/atalhocred-v1-temporizada.mp4` tem trilha, efeitos discretos e legendas temporizadas; **não contém locução**. O texto das legendas é o guia de fala, não uma sincronização medida com gravação. Não publicar como versão final com locução. Revisar o resultado com o cliente antes de veicular.

A assinatura da marca foi composta em Figtree, com Atalho 300 e Cred 800. Os logos anexados ao chat não estavam disponíveis como arquivos locais, portanto não foram incorporados como imagens oficiais. O roteiro e os quatro passos foram aprovados no chat. Destino do anúncio: https://atalhocred.com.br; o MP4 não possui link clicável.

## Instalação e desenvolvimento

Usar o checkout existente; não é necessário criar worktree. Node 24 e npm 11 foram usados na produção. Chromium e FFmpeg são pré-requisitos do ambiente.

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

## Renderização

```sh
npm run render
```

Após renderizar, `postrender` normaliza o áudio da versão temporizada para alvo de -16 LUFS e pico verdadeiro de -1,5 dBTP, e converte o vídeo para yuv420p em faixa limitada BT.709 para distribuição.

O script usa Chromium em `/usr/bin/chromium`, H.264, CRF 18, yuv420p e concorrência 2. Ajuste o caminho do navegador em outro sistema. A trilha já está incluída em `public/audio`. Para recriá-la: `python3 scripts/audio.py`.

## Integrar locução

1. Gravar o roteiro aprovado em português brasileiro, com pausas, em aproximadamente 42 segundos.
2. Salvar em `public/audio/locucao-pt-BR.wav` (preferencialmente WAV 48 kHz).
3. Ajustar a lista `captions` e os limites das cenas em `src/index.tsx` à gravação. Os mesmos tempos das legendas devem ser atualizados no SRT.
4. Renderizar com:

```sh
npx remotion render src/index.tsx AtalhoCred out/atalhocred-com-locucao.mp4 --browser-executable=/usr/bin/chromium --concurrency=2 --codec=h264 --crf=18 --pixel-format=yuv420p --props='{"voiceover":"audio/locucao-pt-BR.wav"}'
```

A música é automaticamente reduzida quando `voiceover` está presente. Rever volume, inteligibilidade, picos e loudness com a voz final; a redução automática não substitui mixagem.

## Alterações

- `src/index.tsx`: cenas, palavras, marca, paleta, animações, tempos e legendas.
- `src/font.ts`: carregamento da Figtree.
- `public/fonts/OFL.txt`: licença da fonte, obtida do repositório Google Fonts.
- `public/audio/trilha-original.wav` e `scripts/audio.py`: áudio e gerador original.
- `captions/atalhocred.srt`: guia de legendas.
- `PRE_PRODUCAO_ATALHOCRED.md`: direção criativa e storyboard.

Para substituir a assinatura tipográfica, colocar o logo oficial em `public/brand/` e usar o componente `Img` de Remotion com `staticFile`, preservando proporção e respiro.

## Verificação técnica

```sh
npx tsc --noEmit
python3 scripts/verify.py
```

## Revisão

Conferir em celular e nos posicionamentos reais do anúncio: leitura, margens de interface, marca, domínio e condições comerciais. Na finalização com voz, verificar sincronização, volume e duração. As margens adotadas são uma referência conservadora e precisam ser conferidas por posicionamento. A trilha sintetizada é original deste projeto; não houve seleção de fonograma de terceiros.
