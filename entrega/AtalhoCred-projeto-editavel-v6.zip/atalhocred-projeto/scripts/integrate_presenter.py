"""V5: uploaded Flow opening, followed by the synchronized V4 motion edit.
Keep the Flow audio with its face. Requires FFmpeg with drawtext and the included Figtree.
"""
from pathlib import Path
import subprocess
Path('out').mkdir(exist_ok=True)
Path('captions/abertura-1.txt').write_text('Você já fez o trabalho.')
Path('captions/abertura-2.txt').write_text('Mas seus honorários\nainda estão esperando?')
font='public/fonts/Figtree.ttf'
label=lambda file,start,end:f"drawtext=fontfile={font}:textfile={file}:fontsize=44:fontcolor=0xEFF3EE:line_spacing=12:box=1:boxcolor=0x01210E@0.92:boxborderw=20:x=(w-text_w)/2:y=1515:enable='between(t,{start},{end})'"
filters=(
 '[0:v]trim=start=0.25:end=6.05,setpts=PTS-STARTPTS,scale=1080:1920:flags=lanczos:out_color_matrix=bt709:out_range=tv,fps=30,setsar=1,trim=end_frame=174,'+label('captions/abertura-1.txt',.32,1.65)+','+label('captions/abertura-2.txt',3,5.48)+'[intro];'
 '[1:v]trim=start=4.6:end=36,setpts=PTS-STARTPTS,fps=30,setsar=1[tail];'
 '[intro][tail]concat=n=2:v=1:a=0[v];'
 '[0:a]atrim=start=0.25:end=6.05,asetpts=N/SR/TB,aresample=48000,aformat=channel_layouts=stereo,volume=5dB[voice];'
 '[2:a]atrim=end_sample=278400,asetpts=N/SR/TB,volume=0.25,afade=t=in:d=0.2,afade=t=out:st=5.60:d=0.2[bed];'
 '[voice][bed]amix=inputs=2:normalize=0,atrim=end_sample=278400,asetpts=N/SR/TB[head];'
 '[1:a]atrim=start=4.6:end=36,asetpts=N/SR/TB,aresample=48000,aformat=channel_layouts=stereo,afade=t=in:d=0.12[tailaudio];'
 '[head][tailaudio]concat=n=2:v=0:a=1[a]'
)
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i','public/video/apresentador-abertura.mp4','-i','public/video/base-motion-v4.mp4','-i','public/audio/trilha-dinamica.wav','-filter_complex',filters,'-map','[v]','-map','[a]','-c:v','libx264','-crf','18','-preset','medium','-threads','2','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','aac','-b:a','192k','-ar','48000','-t','37.2','-movflags','+faststart','out/atalhocred-v5-teste-apresentador.mp4'],check=True)
print('V5 presenter test exported: 37.2 seconds')
