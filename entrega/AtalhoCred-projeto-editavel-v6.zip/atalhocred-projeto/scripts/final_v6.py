"""V6: rebuild soundtrack from clean voices and a continuous bed, no transition FX.
Run integrate_presenter.py and audio_v6.py first to reproduce from project assets.
"""
from pathlib import Path
import subprocess,re,json,wave
A=Path('public/audio');O=Path('out');O.mkdir(exist_ok=True)
def ff(*args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)
def stats(p):
 r=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-af','loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 return json.loads(re.findall(r'\{[^{}]+\}',r.stderr)[-1])
def gain(src,dst,target,peak):
 s=stats(src);db=min(target-float(s['input_i']),peak-float(s['input_tp']))
 ff('-i',src,'-af',f'volume={db}dB,asetpts=N/SR/TB','-ar','48000','-ac','2',dst)
 return {'gain_db':db,'source':s}
# Use the native Flow audio for its face and the available clean narration over graphics.
ff('-i','public/video/apresentador-abertura.mp4','-i',A/'locucao-v3.wav','-filter_complex','[0:a]atrim=start=0.25:end=6.05,asetpts=N/SR/TB,aresample=48000,aformat=channel_layouts=stereo,volume=5dB[a];[1:a]atrim=start=4.6:end=36,asetpts=N/SR/TB,aresample=48000,aformat=channel_layouts=stereo,volume=0.86dB[b];[a][b]concat=n=2:v=0:a=1,atrim=end_sample=1785600,asetpts=N/SR/TB[voice]','-map','[voice]','-ar','48000','-ac','2',A/'vozes-v6.wav')
measurements={'music_gain':gain(A/'trilha-suave-v6.wav',O/'bed-v6.wav',-26,-7)}
ff('-i',A/'vozes-v6.wav','-i',O/'bed-v6.wav','-filter_complex','[0:a]asplit=2[v][control];[1:a][control]sidechaincompress=threshold=0.025:ratio=3:attack=25:release=450[bed];[v][bed]amix=inputs=2:normalize=0:duration=longest,atrim=end_sample=1785600,asetpts=N/SR/TB[mix]','-map','[mix]','-ar','48000','-ac','2',O/'mix-v6-prenorm.wav')
measurements['mix_gain']=gain(O/'mix-v6-prenorm.wav',A/'mix-v6.wav',-16,-1.8)
with wave.open(str(A/'mix-v6.wav')) as w:assert w.getnframes()==1785600 and w.getframerate()==48000
ff('-i',O/'atalhocred-v5-teste-apresentador.mp4','-i',A/'mix-v6.wav','-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-ar','48000','-t','37.2','-movflags','+faststart',O/'atalhocred-v6-sem-popup.mp4')
measurements['final']=stats(O/'atalhocred-v6-sem-popup.mp4')
Path(O/'audio-v6-measurements.json').write_text(json.dumps(measurements,indent=2))
print('V6 exported; visual stream copied without recompression. New audio contains only voices + smooth music.')
