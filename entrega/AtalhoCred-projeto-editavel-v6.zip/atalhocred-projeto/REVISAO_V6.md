# V6 — mixagem sem sons de pop-up

A trilha foi reconstruída sem sinais de transição, arpejos agudos, claps e impactos. O ritmo permanece em 116 BPM com acordes, baixo e texturas suaves. A música agora é contínua durante todo o filme e reduzida durante a fala.

A mixagem utiliza somente as faixas de voz limpas: áudio Flow do apresentador na abertura e locução ElevenLabs disponível sobre os gráficos. O áudio misturado das versões anteriores não foi reaproveitado. Isso evita manter efeitos embutidos na faixa antiga.

Validações: 37,2 s, 1080 × 1920, 30 fps, 1.116 frames, H.264/AAC 48 kHz. O fluxo de vídeo tem hash idêntico ao da V5 (nenhuma recompressão ou mudança de timing das imagens e legendas). Comparação do áudio exportado com a mixagem não detectou deslocamento nos pontos 1, 8, 16, 24 e 33 segundos. Loudness medido: -16,40 LUFS integrados; pico verdadeiro -1,81 dBTP. Decodificação completa executada sem erros reportados.

Não houve avaliação auditiva humana nesta sessão. A abertura mantém o apresentador recebido; não foram geradas novas falas ou novos clipes. O restante usa os gráficos existentes. Rótulo “Representação ilustrativa” permanece removido.
