# V5 — primeiro teste com apresentador

Clipe Flow recebido: 8 s, 720 × 1280, 24 fps. Trecho 0,25–6,05 s integrado à abertura, com áudio original do clipe, para preservar sua relação audiovisual. Saída de 37,2 s, 1080 × 1920, 30 fps, H.264/AAC 48 kHz, 1.116 frames.

Fala reconhecida localmente no clipe: “Você já fez o trabalho? Mas seus honorários ainda estão esperando?”. Legendas derivadas do roteiro aprovado e dos intervalos de fala detectados. As legendas e o áudio do restante da V4 foram deslocados juntos em 1,2 s. Duas comparações de áudio verificaram ausência de deslocamento relevante entre o áudio original recortado e a abertura exportada.

Loudness final medido: -16,49 LUFS integrados; pico verdadeiro -1,85 dBTP. O arquivo foi decodificado integralmente, sem erros reportados. Amostras visuais inspecionadas na fala, na pausa e na passagem para os gráficos. Não houve avaliação auditiva humana nesta sessão.

Limitações do teste: fonte do apresentador em 720p ampliada; movimento convertido de 24 para 30 fps por duplicação de quadros. A voz Flow está apenas na abertura, e a voz ElevenLabs permanece no restante. Revisar a continuidade vocal antes de produzir os outros clipes. Não há apresentador na solução ou no fechamento nesta versão. Rótulo “Representação ilustrativa” permanece removido.
