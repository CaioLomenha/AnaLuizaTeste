# V6 — versão refinada sem sons de pop-up

Versão atual: `out/atalhocred-v6-sem-popup.mp4`, 37,2 segundos. Apresentador na abertura, motion nos demais trechos, legendas e CTA preservados. Usa a voz Flow na abertura e a voz ElevenLabs disponível na narração, conforme a orientação de finalizar com os materiais existentes.

A trilha foi reconstruída sem efeitos de transição, sinais de notificação, arpejos agudos, claps ou impactos. Mantém pulsação a 116 BPM com acordes, baixo e ritmo suave. A música é contínua do início ao fim e reduzida sob a fala. O áudio antigo do vídeo não é usado na mixagem final, evitando efeitos residuais.

## Reproduzir a entrega

```sh
npm run render:final
```

Requer FFmpeg, Python e numpy (para sintetizar música). O comando integra o apresentador, gera a trilha limpa e remuxa o vídeo com a nova mixagem. A etapa final copia o vídeo sem recompressão, preservando os quadros e a sincronização visual da V5.

Arquivos principais: `scripts/audio_v6.py` (trilha), `scripts/final_v6.py` (vozes, mixagem e exportação), `public/audio/mix-v6.wav` (mix completo), `captions/atalhocred-v5.srt` (legendas, iguais na V6). A documentação abaixo descreve a montagem-base.

---

# V5 — teste com apresentador na abertura

O clipe Flow enviado pelo cliente foi integrado à abertura, preservando seu áudio original. A locução ElevenLabs continua nos gráficos seguintes; a diferença de voz deve ser avaliada pelo cliente. Este teste não inclui o apresentador na solução ou no fechamento.

- Fonte: 720 × 1280, 24 fps, 8 s; redimensionada para a montagem em 1080 × 1920, 30 fps.
- Trecho usado: 0,25–6,05 s do clipe. Fala original mantida, sem substituir por outra voz.
- Abertura de 5,8 s + gráficos V4 a partir de 4,6 s = 37,2 s.
- Legendas da abertura ajustadas ao áudio Flow; demais legendas deslocadas em 1,2 s junto com o restante do filme.
- Rótulo “Representação ilustrativa” continua removido.

Para reproduzir o teste:

```sh
npm run render:presenter
```

Requer Python e FFmpeg com drawtext. Fontes e vídeos-base estão incluídos. Saída: `out/atalhocred-v5-teste-apresentador.mp4`. A montagem do teste usa uma cópia da V4 em `public/video/base-motion-v4.mp4` e o clipe recebido em `public/video/apresentador-abertura.mp4`.

Para alterar o motion, usar o projeto Remotion abaixo, renderizar a nova base e atualizar o arquivo base-motion-v4.mp4 antes de executar a integração. `captions/atalhocred-v5.srt` contém as legendas deste teste; o SRT sem sufixo corresponde à base V4.

---

# AtalhoCred — V4 sem rótulo nos cards

36 segundos, vertical 1080 × 1920, 30 fps, H.264/AAC. A V4 retira “Representação ilustrativa” dos cards e mantém a sincronização da V3. Ainda não inclui apresentador animado; consultar FLOW_PROMPTS.md e AVATAR_INTEGRACAO.md para gerar os clipes externamente. Voz ElevenLabs fornecida pelo cliente, trilha original a 116 BPM, paleta oficial, Figtree e CTA atalhocred.com.br.

## Correção de sincronização

A mixagem anterior não preservava os tempos previstos após o tratamento da voz. A V3 separa o ajuste de velocidade, redefine os timestamps pelo relógio de amostras e usa ganho constante na normalização. Compressão de amplitude leve e sidechain não alteram a duração. O WAV tem exatamente 1.728.000 amostras por canal a 48 kHz (36 s).

As 12 legendas seguem frases completas. Seus limites foram conferidos nas pausas da voz processada; a entrada acontece ligeiramente antes da primeira sílaba. As cenas entram antes da narração para permitir a animação de entrada. O vídeo permanece em 36 segundos, com velocidade de voz de 88% sem mudança de tom e entrada intencional de 250 ms.

## Instalar e abrir

Use o checkout existente, sem criar worktree. Node 24, npm 11, Chromium e FFmpeg foram usados.

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

## Renderizar

Os áudios prontos estão incluídos. Para renderizar sem regenerar áudio:

```sh
npm run captions
npm run render
```

Saída: `out/atalhocred-v4-sem-rotulo.mp4`. O pós-processamento converte as cores para BT.709 limitado/yuv420p. Ajustar `/usr/bin/chromium` em outro sistema.

Para regenerar trilha e mixagem:

```sh
npm run audio
```

O gerador de trilha requer numpy. A mixagem requer Python e FFmpeg. Não usar `mix_v2.py` para a versão atual; o script vigente é `scripts/mix_v3.py`.

## Editar

- `src/timeline.ts`: cenas, etapas e legendas.
- `src/index.tsx`: direção visual e movimentos.
- `public/audio/locucao-original.mp3`: gravação original do cliente.
- `public/audio/locucao-v3.wav`: voz processada, com tempo preservado.
- `public/audio/mix-v3.wav`: voz e trilha usadas na composição.
- `scripts/audio_v2.py`: trilha original a 116 BPM.
- `scripts/mix_v3.py`: tratamento de voz e mixagem atual.
- `captions/atalhocred.srt`: legendas separadas.
- `public/fonts/OFL.txt`: licença da Figtree.

Se a gravação mudar, refazer a mixagem e medir novamente as pausas antes de atualizar as legendas. Não aplicar deslocamento único a uma faixa que apresente deriva temporal.

## Verificações

```sh
npx tsc --noEmit
python3 scripts/verify.py
python3 scripts/check_sync.py
```

A checagem de sincronização requer numpy e compara o áudio AAC exportado com a mixagem em cinco posições, além de conferir as entradas de legenda contra os limites de frase medidos. A verificação automatizada não substitui a revisão audiovisual do cliente.

Para gerar o projeto portátil: `python3 scripts/package.py`. O pacote exclui dependências, entregas anteriores e renders. Logos do chat não estavam disponíveis como arquivos locais: a assinatura é composta em Figtree (Atalho 300, Cred 800). Configurar https://atalhocred.com.br como destino do anúncio.
