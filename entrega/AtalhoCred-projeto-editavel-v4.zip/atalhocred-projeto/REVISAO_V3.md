# V3 — correção de sincronização

O usuário identificou atraso na V2. A comparação entre a voz original, a faixa processada e os tempos de legenda confirmou que a cadeia anterior de tratamento de áudio não correspondia ao relógio usado na timeline.

## Correção

- Tratamento de velocidade separado da mixagem; timestamps redefinidos por amostra após atempo.
- Entrada intencional de 250 ms; duração de 36 segundos por contagem exata de amostras.
- Normalização com ganho constante e compressão leve de amplitude, sem alteração de tempo.
- Voz e música mantidas no mesmo relógio de 48 kHz.
- 12 legendas por frase, ancoradas nas pausas medidas da voz final. Entradas até 60 ms antes da primeira sílaba detectada.
- Cards antecipados para que a animação de entrada acompanhe a explicação.

O conteúdo por frase foi conferido com reconhecimento local Whisper tiny via Sherpa ONNX. O modelo identificou as frases, mas apresentou erros de grafia e no nome da marca; o roteiro aprovado permaneceu como fonte textual. Os limites de fala foram medidos diretamente na faixa processada, sem depender dos tempos estimados pelo reconhecedor.

## Verificação

TypeScript, dimensões, codecs, contagem de frames e contagem de amostras verificados por ferramentas. A checagem `scripts/check_sync.py` compara o áudio decodificado do MP4 com a mixagem original em cinco posições para detectar deslocamento ou deriva na exportação. A mesma checagem compara as entradas de legenda com os inícios de frase medidos.

Amostra visual da legenda mais longa conferida: três linhas dentro da área reservada, sem corte. Não houve avaliação auditiva humana nesta sessão; o cliente deve revisar a percepção audiovisual da nova versão.

A V3 mantém a identidade visual, a voz fornecida, a trilha dinâmica de 116 BPM e o CTA. V1 e V2 permanecem no GitHub apenas como histórico.
