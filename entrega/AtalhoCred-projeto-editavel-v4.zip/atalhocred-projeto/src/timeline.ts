// V3: sentence boundaries measured on the final processed voice, not extrapolated.
// 48 kHz sample clock, 0.88x tempo, timestamps reset before a 250 ms lead-in.
export const FPS = 30;
export const DURATION = 36;
// Scene changes anticipate the first spoken word to allow for the entrance animation.
export const SCENES = [[0,138],[138,138],[276,170],[446,369],[815,265]];
export const STEP_STARTS = [0,64,166,249];
export const captions: readonly (readonly [number,number,string])[] = [
 [0.27,1.76,'Você já fez o trabalho.'],
 [2.06,4.57,'Mas seus honorários ainda estão esperando?'],
 [4.88,6.77,'O processo tem seu tempo.'],
 [7.06,9.55,'Seu escritório tem planos para agora.'],
 [9.80,15.04,'Com a AtalhoCred, você pode avaliar a antecipação dos seus honorários advocatícios.'],
 [15.21,17.07,'Envie as informações do crédito.'],
 [17.31,20.50,'Nossa equipe analisa a possibilidade de antecipação.'],
 [20.70,23.33,'Você conhece a proposta e suas condições.'],
 [23.48,27.50,'Após a formalização, o recebimento segue os termos acordados.'],
 [27.66,30.29,'Seu escritório pode ter planos para agora.'],
 [30.49,31.48,'AtalhoCred.'],
 [31.64,32.91,'Solicite uma análise.']
];
