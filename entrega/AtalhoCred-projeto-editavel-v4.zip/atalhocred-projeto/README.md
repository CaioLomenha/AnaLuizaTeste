# AtalhoCred — V4 sem rótulo nos cards

36 segundos, vertical 1080 × 1920, 30 fps, H.264/AAC. A V4 retira “Representação ilustrativa” dos cards e mantém a sincronização da V3. Ainda não inclui apresentador animado; consultar FLOW_PROMPTS.md e AVATAR_INTEGRACAO.md para gerar os clipes externamente. Voz ElevenLabs fornecida pelo cliente, trilha original a 116 BPM, paleta oficial, Figtree e CTA atalhocred.com.br.

## Correção de sincronização

A mixagem anterior não preservava os tempos previstos após o tratamento da voz. A V3 separa o ajuste de velocidade, redefine os timestamps pelo relógio de amostras e usa ganho constante na normalização. Compressão de amplitude leve e sidechain não alteram a duração. O WAV tem exatamente 1.728.000 amostras por canal a 48 kHz (36 s).

As 12 legendas seguem frases completas. Seus limites foram conferidos nas pausas da voz processada; a entrada acontece ligeiramente antes da primeira sílaba. As cenas entram antes da narração para permitir a animação de entrada. O vídeo permanece em 36 segundos, com velocidade de voz de 88% sem mudança de tom e entrada intencional de 250 ms.

## Instalar e abrir

Use o checkout existente, sem criar worktree. Node 24, npm 11, Chromium e FFmpeg foram usados.

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

## Renderizar

Os áudios prontos estão incluídos. Para renderizar sem regenerar áudio:

```sh
npm run captions
npm run render
```

Saída: `out/atalhocred-v4-sem-rotulo.mp4`. O pós-processamento converte as cores para BT.709 limitado/yuv420p. Ajustar `/usr/bin/chromium` em outro sistema.

Para regenerar trilha e mixagem:

```sh
npm run audio
```

O gerador de trilha requer numpy. A mixagem requer Python e FFmpeg. Não usar `mix_v2.py` para a versão atual; o script vigente é `scripts/mix_v3.py`.

## Editar

- `src/timeline.ts`: cenas, etapas e legendas.
- `src/index.tsx`: direção visual e movimentos.
- `public/audio/locucao-original.mp3`: gravação original do cliente.
- `public/audio/locucao-v3.wav`: voz processada, com tempo preservado.
- `public/audio/mix-v3.wav`: voz e trilha usadas na composição.
- `scripts/audio_v2.py`: trilha original a 116 BPM.
- `scripts/mix_v3.py`: tratamento de voz e mixagem atual.
- `captions/atalhocred.srt`: legendas separadas.
- `public/fonts/OFL.txt`: licença da Figtree.

Se a gravação mudar, refazer a mixagem e medir novamente as pausas antes de atualizar as legendas. Não aplicar deslocamento único a uma faixa que apresente deriva temporal.

## Verificações

```sh
npx tsc --noEmit
python3 scripts/verify.py
python3 scripts/check_sync.py
```

A checagem de sincronização requer numpy e compara o áudio AAC exportado com a mixagem em cinco posições, além de conferir as entradas de legenda contra os limites de frase medidos. A verificação automatizada não substitui a revisão audiovisual do cliente.

Para gerar o projeto portátil: `python3 scripts/package.py`. O pacote exclui dependências, entregas anteriores e renders. Logos do chat não estavam disponíveis como arquivos locais: a assinatura é composta em Figtree (Atalho 300, Cred 800). Configurar https://atalhocred.com.br como destino do anúncio.
