"""Sample-stable mix. Normalization uses constant gain; never changes timing.
Reset PTS after tempo processing; align by samples, not inherited MP3 timestamps.
"""
import subprocess,json,re,math,wave
from pathlib import Path
A=Path('public/audio'); O=Path('out');O.mkdir(exist_ok=True)
def ff(*args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)
def stats(path):
 r=subprocess.run(['ffmpeg','-hide_banner','-i',str(path),'-af','loudnorm=I=-16:TP=-1.8:LRA=7:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
 return json.loads(re.findall(r'\{[^{}]+\}',r.stderr)[-1])
def normalize(src,dst,target,peak):
 s=stats(src);gain=min(target-float(s['input_i']),peak-float(s['input_tp']))
 ff('-i',src,'-af',f'volume={gain:.6f}dB,asetpts=N/SR/TB','-ar','48000','-ac','2',dst)
 return {'source':str(src),'gain_db':gain,'measured':s}
# Separate tempo treatment from gain processing. Padding/trimming uses sample indices.
ff('-i',A/'locucao-original.mp3','-af','aresample=48000,atempo=0.88,asetpts=N/SR/TB,adelay=12000S:all=1,apad=whole_len=1728000,atrim=end_sample=1728000,asetpts=N/SR/TB','-ar','48000','-ac','2',O/'voice-v3-timed.wav')
ff('-i',O/'voice-v3-timed.wav','-af','acompressor=threshold=0.025:ratio=2.5:attack=5:release=90:makeup=1,asetpts=N/SR/TB','-ar','48000','-ac','2',O/'voice-v3-compressed.wav')
logs=[normalize(O/'voice-v3-compressed.wav',A/'locucao-v3.wav',-17,-2)]
logs.append(normalize(A/'trilha-dinamica.wav',A/'trilha-v3.wav',-22,-3))
ff('-i',A/'locucao-v3.wav','-i',A/'trilha-v3.wav','-filter_complex','[0:a]asplit=2[voice][control];[1:a][control]sidechaincompress=threshold=0.025:ratio=4:attack=15:release=280:makeup=1[bed];[voice][bed]amix=inputs=2:normalize=0:duration=longest,atrim=end_sample=1728000,asetpts=N/SR/TB[out]','-map','[out]','-ar','48000','-ac','2',O/'mix-v3-prenorm.wav')
logs.append(normalize(O/'mix-v3-prenorm.wav',A/'mix-v3.wav',-16,-1.8))
for p in [A/'locucao-v3.wav',A/'mix-v3.wav']:
 with wave.open(str(p)) as w:assert w.getframerate()==48000 and w.getnframes()==1728000,(p,w.getnframes())
json.dump(logs,open(O/'mix-v3-measurements.json','w'),indent=2)
print('V3: 36 s, exact sample count; constant-gain normalization; 250 ms intentional lead-in.')
