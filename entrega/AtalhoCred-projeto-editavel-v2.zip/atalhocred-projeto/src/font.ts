import { delayRender, continueRender, staticFile } from 'remotion';
export function loadFont() { const handle = delayRender('Figtree'); const font = new FontFace('Figtree', `url(${staticFile('fonts/Figtree.ttf')})`, { weight: '300 900' }); font.load().then(f => { (document.fonts as FontFaceSet & {
    add(font: FontFace): void;
}).add(f); continueRender(handle); }).catch(e => { throw e; }); }
