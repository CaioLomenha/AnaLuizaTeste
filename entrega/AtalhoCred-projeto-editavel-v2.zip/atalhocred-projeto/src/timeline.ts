// Timeline aligned to the supplied recording's sentence pauses after 0.88x tempo + 250 ms lead-in.
export const FPS = 30;
export const DURATION = 36;
export const SCENES = [[0,144],[144,150],[294,160],[454,374],[828,252]];
export const STEP_STARTS = [0,63,165,248];
export const captions: readonly (readonly [number,number,string])[] = [
 [0.25,1.65,'Você já fez o trabalho.'],
 [2.10,4.52,'Mas seus honorários ainda estão esperando?'],
 [4.91,6.61,'O processo tem seu tempo.'],
 [7.13,9.51,'Seu escritório tem planos para agora.'],
 [9.82,12.10,'Com a AtalhoCred, você pode avaliar'],
 [12.10,14.82,'a antecipação dos seus honorários advocatícios.'],
 [15.26,16.94,'Envie as informações do crédito.'],
 [17.36,20.46,'Nossa equipe analisa a possibilidade de antecipação.'],
 [20.75,23.29,'Você conhece a proposta e suas condições.'],
 [23.51,24.98,'Após a formalização,'],
 [24.98,27.23,'o recebimento segue os termos acordados.'],
 [27.73,30.25,'Seu escritório pode ter planos para agora.'],
 [30.52,31.44,'AtalhoCred.'],
 [31.69,32.88,'Solicite uma análise.']
];
