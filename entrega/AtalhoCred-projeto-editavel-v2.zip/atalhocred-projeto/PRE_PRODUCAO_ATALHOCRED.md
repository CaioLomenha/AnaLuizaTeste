# AtalhoCred — pré-produção para aprovação

Status: roteiro, storyboard e fluxo operacional aprovados pelo usuário no chat. Identidade e CTA confirmados. Primeira versão temporizada entregue; versão 2 com voz fornecida pelo usuário e trilha dinâmica adaptada para 36 segundos. Os tempos abaixo documentam a proposta inicial; a timeline vigente está em src/timeline.ts.

## Referência e recursos verificados

O acesso ao vídeo do LinkedIn foi bloqueado pelo proxy com HTTP 403. O vídeo não foi assistido; não há análise atribuída ao seu conteúdo. A proposta abaixo foi criada a partir do briefing.

Disponíveis nesta máquina: Node.js 24.19.0, npm 11.9.0, Python 3.12.14, Chromium, FFmpeg e ffprobe. O FFmpeg anuncia codificadores libx264 e AAC. O checkout não contém um projeto instalado.

A consulta ao registro confirmou a disponibilidade de `@remotion/renderer` 4.0.538; as consultas a React e Remotion retornaram HTTP 503. Isso não valida instalação nem compatibilidade: a cadeia completa precisa ser instalada e testada após a aprovação. A listagem global do npm falhou por diretório global ausente; usar cache e diretórios graváveis no workspace na implementação.

Não há ferramenta de geração de voz exposta na sessão; as verificações locais também não encontraram edge-tts, TTS, pyttsx3, espeak ou piper. Não há voz ou trilha selecionada. O caminho disponível é receber locução gravada ou preparar versão temporizada, com integração posterior. Nenhum serviço de voz foi contratado ou usado.

## Conceito: o tempo do processo e o tempo do escritório

Seu trabalho já foi feito. Mas seus honorários ainda estão esperando?

Uma linha gráfica representa o tempo de recebimento. No início, ela forma um circuito de espera em torno de um documento jurídico. Ao longo do filme, acompanha os planos do escritório, atravessa uma análise e se transforma em um caminho entre o crédito e uma possível antecipação. O mesmo elemento conecta todas as cenas, criando continuidade audiovisual.

A transformação visual não deve sugerir aprovação automática: existe uma etapa explícita de análise e uma proposta com condições antes de qualquer representação de recebimento. Sem cronômetros de aprovação, saldo fictício, percentuais, selos de garantia ou dinheiro surgindo instantaneamente.

## Formato e direção visual

- 42 segundos, vertical 1080 × 1920, 30 fps, 1.260 frames; entrega MP4 H.264 com áudio AAC.
- Motion graphics vetoriais originais: documentos, linha temporal, agenda e interface ilustrativa. Sem imagens de banco ou cópia de elementos da referência.
- Paleta oficial: #07BB50 para destaques, “Cred” do logo e CTAs; #01210E para fundos escuros e textos sobre fundo claro; #EFF3EE para fundos claros; #000000 como preto de apoio. Alternar fundo claro na apresentação do problema e fundo verde escuríssimo na solução e no encerramento, mantendo continuidade pela linha verde principal. Preferir texto #01210E sobre CTA #07BB50 e texto #EFF3EE sobre fundo #01210E, verificando contraste na implementação.
- Figtree em todas as artes. Na assinatura tipográfica do logo, “Atalho” em peso 300 e “Cred” em peso 800, respeitando os arquivos oficiais enviados. Nos textos, usar pesos 400, 600 e 800 para hierarquia. A fonte ainda precisa ser obtida e sua licença registrada antes da produção. Texto principal entre 64–88 px, apoio entre 40–48 px e legendas entre 44–52 px, a conferir no enquadramento final.
- Área inicial para informações essenciais: x=96–900, y=240–1480. Reservar margem direita aos controles e região inferior às interfaces das plataformas. Conferir os posicionamentos escolhidos na revisão; não existe margem universal para todas as interfaces e formatos de anúncio.
- Legendas em até duas linhas, quebradas por sentido, em faixa de alto contraste. Reservar área própria para não competir com cards ou CTA. Sincronizar por trechos da locução real e entregar também SRT.
- Usar os logos fornecidos pelo usuário, preservando proporções, composição e área de respiro. Validar resolução e transparência dos arquivos antes de ampliar; não redesenhar nem animar separadamente partes da assinatura sem necessidade. Priorizar a versão de melhor leitura em tela de celular.
- CTA final: “Solicite uma análise.” com “atalhocred.com.br” visível abaixo. Destino de clique informado pelo usuário: https://atalhocred.com.br. Configurar esse destino no anúncio ou no canal de publicação; o MP4 não contém botão clicável.

## Roteiro e storyboard

| Tempo | Locução em português brasileiro | Texto principal de tela | Ação visual e ritmo |
|---|---|---|---|
| 0–5 s | Você já fez o trabalho. Mas seus honorários ainda estão esperando? | Seu trabalho já foi feito. / E os honorários? | Abrir em detalhe de um documento abstrato. A palavra “feito” se estabiliza; a linha segue para uma data futura e desenha um circuito de espera. Aproximar “honorários” com movimento contido, sem digitação artificial. |
| 5–11 s | O processo tem seu tempo. Seu escritório tem planos para agora. | O processo tem seu tempo. / Seu escritório tem planos. | A câmera acompanha a mesma linha. Surgem agenda, equipe e estrutura do escritório em três sinais gráficos. As datas continuam avançando, enquanto os planos permanecem em primeiro plano. Sem simular uma plataforma real da empresa. |
| 11–18 s | Com a AtalhoCred, você pode avaliar a antecipação dos seus honorários advocatícios. | AtalhoCred / Avalie a antecipação de honorários | O enquadramento se abre, revelando o nome da marca. A linha chega ao ponto “Análise”; só então apresenta um caminho possível entre “Recebimento futuro” e “Antecipação”. A animação explica a alternativa sem prometer aprovação. |
| 18–22 s | Envie as informações do crédito. | 01 / Informações do crédito | Um documento se encaixa em uma área de envio ilustrativa. A linha se transforma no contorno desse painel. |
| 22–26 s | Nossa equipe analisa a possibilidade de antecipação. | 02 / Análise da possibilidade | O documento abre seus campos; uma lente abstrata percorre as informações. Não usar um check de aprovação. |
| 26–30 s | Você conhece a proposta e suas condições. | 03 / Proposta e condições | O painel se reorganiza em proposta, evidenciando condições de forma abstrata, sem inventar taxas ou números. Pausa de leitura. |
| 30–35 s | Após a formalização, o recebimento segue os termos acordados. | 04 / Formalização e recebimento | Um traço de assinatura conclui a formalização. O caminho chega ao ponto “Recebimento”, acompanhado de “Conforme os termos acordados”. Sem representar liberação imediata. |
| 35–42 s | Seu escritório pode ter planos para agora. AtalhoCred. Solicite uma análise. | Seu escritório pode ter planos para agora. / Solicite uma análise. / atalhocred.com.br | A linha volta a formar uma composição aberta ao redor da marca. Fundo #01210E, texto #EFF3EE e CTA #07BB50 com texto #01210E. Reduzir a densidade visual e manter CTA, domínio e identificação estáveis nos últimos 3 segundos. Rodapé legível: “Antecipação sujeita à análise e às condições comerciais.” |

O roteiro tem aproximadamente 105 palavras e deve ser interpretado em 42 segundos com pausas naturais. Os quatro passos são uma proposta baseada no briefing, ainda sujeitos à confirmação operacional da AtalhoCred. Texto e timing tornam-se finais após essa confirmação e a aprovação criativa.

## Locução, trilha e som

Voz em português brasileiro, natural e próxima, com segurança e sem tom de locutor de oferta. Começar como uma pergunta feita a um colega. Dar ênfase leve a “seu tempo”, “agora”, “avaliar” e “condições”. Evitar acelerar as etapas comerciais.

Direção musical: instrumental contemporâneo, aproximadamente 96 BPM, base orgânica discreta e textura eletrônica leve, sem voz. A trilha deve ser original ou licenciada para campanhas pagas nas plataformas de destino. Não foi selecionado nem licenciado um fonograma.

Efeitos pontuais de papel, encaixe e passagem de linha, com volume abaixo da fala. Sem efeito de caixa registradora. Mixagem com redução da música durante a locução, alvo inicial de aproximadamente -14 LUFS integrados e pico verdadeiro abaixo de -1 dBTP, a validar no arquivo final.

## Cronograma de animação

Entradas de elementos entre 8 e 14 frames; reorganizações de layout entre 16 e 24 frames; câmera virtual discreta. Usar aceleração e desaceleração suaves, com molas amortecidas apenas onde reforçarem a ação. Sem oscilação de todos os elementos.

0–5: pergunta e espera. 5–11: deslocamento contínuo para o escritório. 11–18: revelação da alternativa e da marca. 18–35: uma única interface que se transforma nos quatro passos, sem quatro slides independentes. 35–39: resolução visual. 39–42: sustentação de marca e CTA.

Animações de palavras-chave acompanham a fala; texto de apoio não precisa repetir toda a locução porque haverá legendas. Cada transição nasce do objeto ou da linha da cena anterior. Fazer revisão em tamanho de celular para verificar hierarquia e tempo de leitura.

## Implementação proposta após aprovação

Priorizar React e Remotion, com SVGs próprios e renderização por Chromium. Separar componentes de cena, tokens visuais, roteiro/timeline, legendas e áudio. Manter durações centralizadas para ajustar a montagem à voz final.

Estrutura prevista: `src/scenes`, `src/components`, `src/design`, `src/timeline`, `public/audio`, `public/brand`, `captions` e `out`. Incluir lockfile, instruções de desenvolvimento/renderização e registro das fontes e licenças utilizadas. Essa estrutura ainda não foi implementada.

Se não houver voz utilizável, preparar após aprovação uma versão temporizada para locução. Integrar a gravação em `public/audio/locucao-pt-BR.wav`, medir a duração e ajustar os marcadores antes da renderização final. Não apresentar uma versão sem voz como entrega audiovisual completa.

## Aprovação e materiais necessários

1. Aprovar o conceito, o roteiro, os textos e a estrutura de 42 segundos.
2. Confirmar se os quatro passos representam o atendimento real, inclusive o momento de apresentação das condições, formalização e recebimento.
3. Identidade recebida: Figtree, paleta oficial e duas imagens de logo. Destino do CTA confirmado: atalhocred.com.br. Conferir qualidade técnica dos arquivos na produção.
4. Definir a fonte de locução e trilha licenciada. Não inserir credenciais em arquivos ou no chat.

## Revisão da primeira versão

Conferir ortografia, contraste, enquadramento, leitura em celular, legendas, pausas, continuidade, marca, condições comerciais e ausência de promessas não comprovadas. Validar duração, dimensões, codecs, taxa de quadros e áudio com ffprobe; assistir ao arquivo integral para verificar sincronização e artefatos. Entregar MP4, projeto editável, SRT e instruções de alteração depois das fases de aprovação e revisão.
