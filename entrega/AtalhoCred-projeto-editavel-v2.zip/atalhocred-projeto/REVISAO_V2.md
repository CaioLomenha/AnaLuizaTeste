# Revisão — versão 2 com locução

## Alterações

Voz fornecida pelo cliente, preservada no projeto. Ajuste de velocidade para 88% sem transposição, entrada de 250 ms e montagem de 36 segundos. Legendas e cenas alinhadas às pausas detectadas no arquivo. Trilha original substituída por nova composição a 116 BPM, com baixo, percussão e arpejos. Sidechain reduz a música durante a locução.

## Verificações executadas

- TypeScript: `npx tsc --noEmit`, concluído sem erros.
- Render: 1.080 frames, 30 fps, 1080 × 1920, H.264/yuv420p, BT.709 limitado; vídeo de 36 s. Contêiner de 36,011 s por padding AAC.
- Áudio AAC estéreo, 48 kHz, fala e música integradas.
- Arquivo final decodificado integralmente pelo FFmpeg sem erros reportados.
- Mix final medida: -15,91 LUFS integrados, pico verdadeiro -1,77 dBTP, faixa de loudness 2,60 LU.
- 14 entradas de legenda em SRT e no vídeo. O roteiro aprovado foi alinhado às pausas da gravação; o texto não passou por reconhecimento automático, pois o download do modelo foi bloqueado pela rede.
- Oito amostras visuais inspecionadas: abertura, problema, solução, quatro etapas e encerramento. Texto, CTA e domínio aparecem no enquadramento previsto nessas amostras.
- Não houve avaliação auditiva humana nesta sessão. Conferir pronúncia e sincronização fina na revisão do cliente.

## Mantido

Figtree, paleta oficial, assinatura tipográfica Atalho 300 / Cred 800, CTA atalhocred.com.br e condições comerciais. Os logos anexados ao chat não estavam acessíveis como arquivos locais; a assinatura é tipográfica. Sem promessas de taxa, prazo ou aprovação garantida.
