# AtalhoCred — vídeo com locução e trilha dinâmica

36 segundos, vertical 1080 × 1920, 30 fps, H.264/AAC. React/Remotion, SVGs originais, Figtree, paleta oficial e CTA atalhocred.com.br.

## Versão 2

- Voz fornecida pelo cliente, gerada no ElevenLabs. Original preservado em `public/audio/locucao-original.mp3`.
- Tempo da voz ajustado para 88% com FFmpeg, preservando o tom, mais 250 ms de entrada; áudio final de 36 s.
- Trilha instrumental original sintetizada a 116 BPM, com percussão, baixo, teclas e arpejos; sem samples de terceiros.
- Música reduzida automaticamente durante a fala com sidechain. Mix final com alvo de -16 LUFS e pico verdadeiro máximo de -1,5 dBTP.
- Legendas e cenas ajustadas às pausas detectadas na gravação. Não foi usada transcrição automática; modelo de reconhecimento indisponível por bloqueio de rede. Revisão humana de pronúncia e sincronização fina recomendada.
- Assinatura tipográfica Figtree: Atalho 300, Cred 800. Logos do chat não estavam disponíveis como arquivos locais.

## Instalar

Usar o checkout existente, sem criar worktree. Node 24 e npm 11; Chromium e FFmpeg disponíveis no ambiente de produção.

```sh
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

Para regenerar a trilha, o gerador Python requer `numpy`; o áudio pronto está incluído, portanto isso não é necessário para renderizar. `mix_v2.py` requer somente Python e FFmpeg.

## Renderizar

```sh
npm run captions
npm run render
```

`postrender` converte o vídeo para BT.709 limitado/yuv420p e valida o arquivo `out/atalhocred-v2-com-locucao.mp4`. O navegador está configurado como `/usr/bin/chromium`; ajustar em outra máquina. A renderização usa concorrência 2 e CRF 18.

## Alterar

- `src/timeline.ts`: limites das cenas, quatro passos e legendas; os tempos já consideram o tratamento da voz.
- `src/index.tsx`: composição, marca, paleta e movimentos.
- `public/audio/locucao-original.mp3`: voz original do cliente.
- `scripts/audio_v2.py`: trilha original a 116 BPM.
- `scripts/mix_v2.py`: velocidade da voz, entrada, normalização e ducking.
- `public/audio/mix-v2.wav`: áudio completo usado pelo vídeo.
- `captions/atalhocred.srt`: legendas separadas.
- `public/fonts/OFL.txt`: licença da Figtree.

Para atualizar a voz, substitua o original, execute `python3 scripts/mix_v2.py`, ajuste a timeline e regenere as legendas antes de renderizar. Não altere a velocidade ou duração sem rever os limites de cena.

Para criar um novo pacote editável: `python3 scripts/package.py`. O ZIP exclui node_modules, saídas de render e a pasta de entrega para evitar duplicação de arquivos.

## Revisão e publicação

Conferir em celular: ritmo, legibilidade, sincronização, pronúncia de AtalhoCred e margens específicas de cada posicionamento. Não há botão clicável no MP4: configurar https://atalhocred.com.br no anúncio.

Não há promessa de aprovação, taxa ou prazo garantidos no filme. Ver `REVISAO_V2.md` para resultados e limites das verificações.
