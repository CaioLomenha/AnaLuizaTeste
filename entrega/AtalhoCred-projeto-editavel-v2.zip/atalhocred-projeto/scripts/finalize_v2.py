"""Deliver BT.709 limited-range H.264/AAC with fast-start metadata."""
import subprocess
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i','out/atalhocred-v2-render.mp4','-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-crf','18','-preset','medium','-threads','2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-c:a','copy','-t','36','-movflags','+faststart','out/atalhocred-v2-com-locucao.mp4'],check=True)
