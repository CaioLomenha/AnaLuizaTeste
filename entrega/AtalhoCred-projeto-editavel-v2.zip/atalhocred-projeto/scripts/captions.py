"""Export the shared caption timeline to SRT (no third-party dependencies)."""
from pathlib import Path
import re
s=Path('src/timeline.ts').read_text()
rows=re.findall(r"\[([\d.]+),([\d.]+),'([^']+)'\]",s)
def tc(v):
 ms=round(float(v)*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);sec,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{sec:02},{ms:03}'
Path('captions/atalhocred.srt').write_text('\n\n'.join(f'{i+1}\n{tc(a)} --> {tc(b)}\n{t}' for i,(a,b,t) in enumerate(rows))+'\n')
print(len(rows),'cues exported')
