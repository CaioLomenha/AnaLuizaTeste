"""Normalize the music-only review export and convert full-range frames to standard BT.709 limited range."""
import subprocess
from pathlib import Path
p=Path('out/atalhocred-v1-temporizada.mp4');tmp=p.with_name('normalized.mp4')
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(p),'-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-crf','18','-preset','medium','-threads','2','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-af','loudnorm=I=-16:TP=-1.5:LRA=7','-c:a','aac','-b:a','192k','-ar','48000','-t','42','-movflags','+faststart',str(tmp)],check=True)
tmp.replace(p)
