"""Original 116 BPM instrumental with percussion, warm keys and bass; no samples.
Requires numpy. Deterministic synthesis; duration and transition accents follow timeline.
"""
from pathlib import Path
import numpy as np
import wave
SR=48000; D=36; beat=60/116; rng=np.random.default_rng(20261023)
out=np.zeros((D*SR,2),np.float64)
def add(start,sound,gain=1,pan=0):
 a=round(start*SR)
 if a>=len(out): return
 if a<0:sound=sound[-a:];a=0
 sound=sound[:len(out)-a];out[a:a+len(sound),0]+=sound*gain*(1-pan*.35);out[a:a+len(sound),1]+=sound*gain*(1+pan*.35)
def tt(d):return np.arange(round(d*SR))/SR
def note(m):return 440*2**((m-69)/12)
# Cmaj9, Am7, Fmaj9, G6: steady harmonic movement, no fanfare.
chords=[[48,55,59,62,64],[45,52,55,60,64],[41,48,52,57,60],[43,50,55,59,64]]
for bar,start in enumerate(np.arange(0,D,beat*4)):
 chord=chords[bar%4]; section=.55 if start<4.8 else (.8 if start<9.8 else 1)
 for m in chord[1:]:
  t=tt(beat*4+.35);env=(1-np.exp(-t*18))*np.exp(-t*1.1)*np.minimum((t[-1]-t)/.2,1)
  y=(np.sin(2*np.pi*note(m)*t+.5*np.sin(2*np.pi*note(m)*2*t)*np.exp(-t*3))+.12*np.sin(2*np.pi*note(m)*3*t))*env
  add(start,y,.018*section,pan=(m%3-1)*.65)
 # Articulated syncopated bass, rounded envelope.
 for offset in [0,1.5,2,3.25]:
  t=tt(.48);f=note(chord[0]-12);y=(np.sin(2*np.pi*f*t)+.12*np.sin(2*np.pi*f*2*t))*(1-np.exp(-t*100))*np.exp(-t*6)
  add(start+offset*beat,y,.10*section)
 # Arpeggio, brighter from solution onward, leaving space around narration.
 for k,offset in enumerate([.5,1.75,2.5,3.5]):
  t=tt(.5);f=note(chord[2+k%3]+12);y=np.sin(2*np.pi*f*t+.35*np.sin(2*np.pi*f*2*t))*np.exp(-t*12)*(1-np.exp(-t*150))
  add(start+offset*beat,y,.025*section,(-1 if k%2 else 1)*.6)
for k,start in enumerate(np.arange(0,D,beat)):
 section=.45 if start<4.8 else (.7 if start<9.8 else 1)
 if k%4 in [0,2]:
  t=tt(.28);freq=47+90*np.exp(-t*28);phase=2*np.pi*np.cumsum(freq)/SR;y=np.sin(phase)*np.exp(-t*15)*(1-np.exp(-t*900));add(start,y,.18*section)
 if k%4 in [1,3]:
  t=tt(.15);noise=rng.normal(0,1,len(t));hp=np.r_[0,np.diff(noise)];y=hp*np.exp(-t*37)*(1-np.exp(-t*2000));add(start,y,.019*section,.1)
 for off in [0,.5]:
  t=tt(.055);noise=rng.normal(0,1,len(t));hp=np.r_[0,np.diff(noise)];y=hp*np.exp(-t*90)*(1-np.exp(-t*2500));add(start+off*beat,y,.008*section,(-.6 if off else .6))
for start in [4.8,9.8,15.15,17.25,20.65,23.4,27.6]:
 t=tt(.19);y=np.sin(2*np.pi*(800*t-1000*t*t))*np.exp(-t*22)*(1-np.exp(-t*600));add(start,y,.025)
# Final branded resolution and smooth full fade.
t=tt(3.2)
for m in [48,55,60,64,67]:add(32.4,np.sin(2*np.pi*note(m)*t)*(1-np.exp(-t*12))*np.exp(-t*1.2),.025)
t=np.arange(len(out))/SR;fade=np.minimum(np.minimum(t/.25,(D-t)/1.3),1).clip(0,1);out*=fade[:,None]
peak=np.max(np.abs(out));out*=.80/max(peak,.01)
Path('public/audio').mkdir(parents=True,exist_ok=True)
with wave.open('public/audio/trilha-dinamica.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes((np.clip(out,-1,1)*32767).astype('<i2').tobytes())
print('Original dynamic instrumental:',D,'s, 116 BPM, stereo 48 kHz')
