"""Create a portable editable project, excluding caches and rendered video."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
root=Path('.'); dest=Path('out/atalhocred-projeto-editavel-v2.zip')
with ZipFile(dest,'w',ZIP_DEFLATED) as z:
 for path in sorted(root.rglob('*')):
  if not path.is_file() or any(p in {'.git','node_modules','out','entrega','__pycache__'} for p in path.parts):continue
  
  if path.as_posix() in {'public/audio/trilha-mix.wav','public/audio/trilha-original.wav'}:continue
  z.write(path,Path('atalhocred-projeto')/path)
print(dest,dest.stat().st_size)
