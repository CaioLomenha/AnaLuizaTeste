"""Original synthesized instrumental bed and understated transition cues; no samples."""
import math, wave, array
from pathlib import Path
SR=48000; DURATION=42
# Am(add9), Fmaj7, Cmaj9, Gsus2; 96 BPM.
chords=[(110,164.8138,246.9417,261.6256),(87.3071,130.8128,164.8138,220),(130.8128,195.9977,246.9417,293.6648),(97.9989,146.8324,220,293.6648)]
beats=.625; data=array.array('h')
transitions=[5,11,18,22,26,30,35]
for i in range(SR*DURATION):
 t=i/SR; chord=chords[int(t/5)%4]; fade=min(t/1.5,1,(42-t)/2)
 pad=sum(math.sin(2*math.pi*f*t+.16*math.sin(t*.6)) for f in chord)/4
 pad*=.13*(.8+.2*math.sin(t*.7))
 phase=t%beats; note=chord[int(t/beats)%4]*2
 pluck=(math.sin(2*math.pi*note*t)+.25*math.sin(2*math.pi*note*2*t))*.075*math.exp(-phase*9)*min(phase/.008,1)
 bass=math.sin(2*math.pi*chord[0]/2*t)*.07*(.8+.2*math.cos(2*math.pi*t/2.5))
 cue=0
 for at in transitions:
  u=t-at
  if 0<=u<.22: cue+=.025*math.sin(2*math.pi*(700*u-900*u*u))*math.exp(-u*20)*min(u/.006,1)
 val=(pad+pluck+bass+cue)*max(0,fade)
 left=val; right=val*.97+.004*math.sin(2*math.pi*chord[2]*t+.3)*fade
 data.extend((int(max(-1,min(1,left))*32767),int(max(-1,min(1,right))*32767)))
Path('public/audio').mkdir(parents=True,exist_ok=True)
with wave.open('public/audio/trilha-original.wav','wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(SR);w.writeframes(data.tobytes())
print('Original instrumental: 42 seconds, stereo, 48kHz')
