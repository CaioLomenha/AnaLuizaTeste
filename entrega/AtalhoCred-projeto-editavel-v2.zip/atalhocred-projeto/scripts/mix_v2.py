"""Mix supplied narration with original music; duck music under speech."""
import subprocess
from pathlib import Path
A=Path('public/audio')
def ff(*args):subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,args)],check=True)
ff('-i',A/'locucao-original.mp3','-af','atempo=0.88,adelay=250:all=1,loudnorm=I=-17:TP=-2:LRA=7,apad,atrim=duration=36','-ar','48000','-ac','2',A/'locucao-pt-BR.wav')
ff('-i',A/'trilha-dinamica.wav','-af','loudnorm=I=-22:TP=-3:LRA=7,apad,atrim=duration=36','-ar','48000','-ac','2',A/'trilha-mix.wav')
ff('-i',A/'locucao-pt-BR.wav','-i',A/'trilha-mix.wav','-filter_complex','[0:a]asplit=2[voice][control];[1:a][control]sidechaincompress=threshold=0.025:ratio=4:attack=15:release=280:makeup=1[bed];[voice][bed]amix=inputs=2:normalize=0:duration=longest,loudnorm=I=-16:TP=-1.5:LRA=7,apad,atrim=duration=36[out]','-map','[out]','-ar','48000','-ac','2',A/'mix-v2.wav')
print('Mixed voice + dynamic music: 36 seconds, 48 kHz stereo')
