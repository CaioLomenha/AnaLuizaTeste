# Revisão — primeira versão temporizada

Arquivo: `out/atalhocred-v1-temporizada.mp4`.

- Exportação validada: 42 segundos, 1080 × 1920, 30 fps, 1.260 frames, H.264/yuv420p, faixa limitada BT.709, AAC estéreo 48 kHz.
- Arquivo decodificado integralmente pelo FFmpeg sem erros reportados.
- TypeScript verificado com `npx tsc --noEmit`.
- Oito amostras visuais inspecionadas: gancho, problema, solução, quatro etapas e encerramento. Não foram observados cortes de texto nessas amostras; confirmar visualização nos posicionamentos reais de veiculação.
- Legendas: 14 entradas, cobrindo o roteiro até 42 segundos. São temporizadas para futura locução; ainda não sincronizadas a uma gravação real.
- Áudio instrumental original: loudness medido em -16,07 LUFS integrados e pico verdadeiro em -4,94 dBTP. Não foi realizada avaliação auditiva humana nesta sessão.
- CTA visível: atalhocred.com.br. O destino precisa ser configurado no anúncio pela equipe que publicar.
- Paleta e Figtree aplicadas. Assinatura composta tipograficamente conforme os pesos informados; anexos de logo não estavam acessíveis como arquivos locais.
- Mensagens condicionadas à análise e aos termos comerciais; sem taxas, prazos garantidos ou promessa de aprovação.

## Pendências para finalização

Locução em português brasileiro, sincronização fina com a voz, revisão auditiva e aprovação audiovisual do cliente. Caso seja exigida reprodução exata do logo anexado, incorporar o arquivo oficial acessível. Esta é a primeira versão para revisão, não uma entrega final com locução.
